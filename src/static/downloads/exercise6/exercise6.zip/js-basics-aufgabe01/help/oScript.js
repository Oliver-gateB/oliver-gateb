console.clear();

console.warn('Dies ist die JavaScript-Konsole.')
console.warn('Ich wünsche dir viel Spass mit JS.')
console.warn('LG Oliver')

function iAmReady() {
    const hook00 = document.querySelector('#hook00');
    hook00.classList.add('alert-success');
    hook00.classList.remove('alert-danger');
    hook00.innerText = 'Ich bin bereit!';
    console.log('');
    console.warn('Dann können wir ja starten!');
}

function runTheNumbers(number1, number2) {
    console.log('number1: ' + number1);
    console.log('number2: ' + number2);

    const hook05 = document.querySelector('#hook05');

    if (!(number1 <= 10 && number1 >= 0 && number2 <= 10 && number2 >= 0)) {
        hook05.innerText = 'Bitte wähle Zahlen zwischen 0 und 10.';
        return;
    }

    const sum = number1 + number2;
    console.log(number1 + ' + ' + number2 + ' = ' + sum);
    const sumGoal = 12;
    const dif = number1 - number2;
    console.log(number1 + ' - ' + number2 + ' = ' + dif);
    const difGoal = 4;
    const pro = number1 * number2;
    console.log(number1 + ' * ' + number2 + ' = ' + pro);
    const proGoal = 32;
    const div = number1 / number2;
    console.log(number1 + ' / ' + number2 + ' = ' + div);
    const divGoal = 2;

    let htmlOutput = '';
    let countCorrect = 0;

    if (sum === sumGoal) {
        htmlOutput += '<strong>' + number1 + ' + ' + number2 + ' = ' + sumGoal + '</strong><br />';
        countCorrect++;
    } else {
        htmlOutput += number1 + ' + ' + number2 + ' != ' + sumGoal + '<br />';
    }
    if (dif === difGoal) {
        htmlOutput += '<strong>' + number1 + ' - ' + number2 + ' = ' + difGoal + '</strong><br />';
        countCorrect++;
    } else {
        htmlOutput += number1 + ' - ' + number2 + ' != ' + difGoal + '<br />';
    }
    if (pro === proGoal) {
        htmlOutput += '<strong>' + number1 + ' * ' + number2 + ' = ' + proGoal + '</strong><br />';
        countCorrect++;
    } else {
        htmlOutput += number1 + ' * ' + number2 + ' != ' + proGoal + '<br />';
    }
    if (div === divGoal) {
        htmlOutput += '<strong>' + number1 + ' / ' + number2 + ' = ' + divGoal + '</strong><br />';
        countCorrect++;
    } else {
        htmlOutput += number1 + ' / ' + number2 + ' != ' + divGoal + '<br />';
    }

    if (countCorrect === 4) {
        hook05.classList.add('alert-success');
        hook05.classList.remove('alert-danger');
    }

    hook05.innerHTML = htmlOutput;

}

let count06 = 0;

function testRock() {
    const hook06 = document.querySelector('#hook06');

    if (typeof letsRock == 'undefined') {
        hook06.innerText = 'Hast du die Funktion richtig aufgebaut?';
        return;
    }

    if (typeof hungry === 'undefined' || hungry !== true) {
        hook06.innerText = 'Irgendwas stimmt mit \'hungry\' nicht.';
        return;
    }

    count06++;

    if (count06 < 5) {
        hook06.innerText = 'Noch nicht ganz korrekt. Bitte 5x ausführen.';
    } else if (count06 === 5) {
        hook06.classList.add('alert-success');
        hook06.classList.remove('alert-danger');
        hook06.innerText = 'Perfekt!';
    } else {
        hook06.classList.remove('alert-success');
        hook06.classList.add('alert-danger');
        hook06.innerText = 'Jetzt hast du’s zu oft ausgeführt.';
    }

}

function printRecipe(output) {
    const hook07 = document.querySelector('#hook07');
    hook07.innerHTML += '<li>' + output + '</li>';
}
